#!/bin/bash
cd -- "$(dirname "$0")"
pwd

# This moves the original framework, if this is the first time running, then links to it. If it does, it links to Sierra's version
if [  ! -f /usr/libexec/diskmanagementd-sierra ]; then
    mv /usr/libexec/diskmanagementd /usr/libexec/diskmanagementd-sierra
    ln -s /usr/libexec/diskmanagementd-sierra /usr/libexec/diskmanagementd
else
    rm /usr/libexec/diskmanagementd  # After Diskutility closes for any reason, we unlink the framework
    ln -s /usr/libexec/diskmanagementd-sierra /usr/libexec/diskmanagementd # Link back to original
    
fi
cp diskmanagementd /usr/libexec/diskmanagementd-elcap # Copy El Capitan's to the same place
rm /usr/libexec/diskmanagementd # Removes the link
ln -s /usr/libexec/diskmanagementd-elcap /usr/libexec/diskmanagementd # Links to El Capitan's version

sudo killall diskmanagementd

./DiskUtility # Runs Diskutility
rm /usr/libexec/diskmanagementd  # After Diskutility closes for any reason, we unlink the framework
ln -s /usr/libexec/diskmanagementd-sierra /usr/libexec/diskmanagementd # Link back to original

sudo killall diskmanagementd