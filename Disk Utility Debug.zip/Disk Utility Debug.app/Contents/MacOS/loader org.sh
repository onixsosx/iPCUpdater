#!/bin/bash
cd -- "$(dirname "$0")"
pwd
mv /usr/libexec/diskmanagementd /usr/libexec/diskmanagementd-sierra && cp diskmanagementd /usr/libexec/diskmanagementd && ./DiskUtility && rm /usr/libexec/diskmanagementd && mv /usr/libexec/diskmanagementd-sierra /usr/libexec/diskmanagementd
